import gradio as gr
import requests
import os
from threading import Thread

API = os.environ.get('API_BASE', 'http://localhost:8000/api/v1/query')

def ask_question(question):
    try:
        resp = requests.post(API, json={'question': question, 'user_id': 'gradio_user'}, timeout=30)
        if resp.status_code == 200:
            data = resp.json()
            answer = data.get('answer') or data.get('error') or str(data)
            meta = ''
            if 'row' in data:
                meta += f"Row: {data.get('row')}\n"
            if 'kpis' in data:
                meta += f"KPIs: {data.get('kpis')}\n"
            if 'audit_id' in data:
                meta += f"AuditId: {data.get('audit_id')}\n"
            return answer, meta
        else:
            return f'Error: {resp.status_code} {resp.text}', ''
    except Exception as e:
        return f'Exception: {e}', ''

def ingest_doc(path):
    def run():
        os.system(f'python backend/chroma_ingest.py {path}')
    Thread(target=run).start()
    return f'Ingestion started for {path}'

with gr.Blocks() as demo:
    gr.Markdown('# CKF - Enterprise Chat Agent (Gradio UI)')
    with gr.Row():
        with gr.Column(scale=3):
            q = gr.Textbox(label='Ask anything about manufacturing data', placeholder='e.g., What is the PackedWeight for product number 203845?')
            btn = gr.Button('Ask')
            output = gr.Textbox(label='Answer', lines=8)
        with gr.Column(scale=1):
            gr.Markdown('## Admin')
            doc_path = gr.Textbox(value=os.environ.get('MANUFACTURING_DOC_URL','file:///mnt/data/Manufacturing_Process_and_KPIs_Documentation.docx'), label='Doc path (file://)')
            ingest_btn = gr.Button('Ingest Document to Chroma')
            ingest_status = gr.Textbox(label='Ingest status')
            meta = gr.Textbox(label='Provenance/KPIs', lines=6)
    btn.click(lambda text: ask_question(text), inputs=[q], outputs=[output, meta])
    ingest_btn.click(lambda p: ingest_doc(p), inputs=[doc_path], outputs=[ingest_status])

if __name__ == '__main__':
    demo.launch(server_name='0.0.0.0', server_port=7860)
