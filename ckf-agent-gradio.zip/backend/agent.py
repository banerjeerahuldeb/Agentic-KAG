import re
from .metadata import DATA_DICTIONARY, RULE_SNIPPETS
from .db import run_sql
from .rag import rag_search
from .kpi_engine import compute_kpis
from .llm import call_llm
from .audits import record_audit

def extract_fields(question: str):
    fields = []
    q = question.lower()
    for col in DATA_DICTIONARY.keys():
        if col.lower() in q:
            fields.append(col)
    return fields

def extract_product_number(question: str):
    m = re.search(r"\b(\d{4,})\b", question)
    return m.group(1) if m else None

def build_sql(fields, product_number=None):
    main_table = DATA_DICTIONARY[fields[0]]['table']
    cols = ', '.join(fields + ['ProductNumber'])
    sql = f"SELECT {cols} FROM {main_table} WHERE 1=1"
    if product_number:
        sql += " AND ProductNumber = :p"
    sql += " ORDER BY CastDate DESC NULLS LAST LIMIT 1"
    return sql

def answer_question(question: str, user_id: str = 'user'):
    fields = extract_fields(question)
    if not fields:
        rag = rag_search(question)
        if rag:
            text = '\n\n'.join([r['text'] for r in rag])
            audit_id = record_audit(user_id, question, '', {}, rag, text)
            return {'answer': text, 'provenance': rag, 'audit_id': audit_id}
        return {'error': 'Could not identify any data fields referenced in the question. Try asking using column names from the data dictionary.'}
    pnum = extract_product_number(question)
    rag = rag_search(question)
    sql = build_sql(fields, pnum)
    params = {'p': pnum} if pnum else {}
    row = run_sql(sql, params)
    if not row:
        if rag:
            text = '\n\n'.join([r['text'] for r in rag])
            audit_id = record_audit(user_id, question, sql, {}, rag, text)
            return {'answer': text, 'provenance': rag, 'audit_id': audit_id, 'sql': sql}
        return {'error': f'No row found for query (product={pnum})', 'sql': sql}
    kpi_out = compute_kpis(row, fields)
    payload = {'question': question, 'sql': sql, 'row': row, 'kpis': kpi_out, 'rules': rag or RULE_SNIPPETS}
    llm_resp = call_llm(payload)
    audit_id = record_audit(user_id, question, sql, kpi_out, rag, llm_resp)
    return {'answer': llm_resp, 'row': row, 'kpis': kpi_out, 'provenance': rag, 'audit_id': audit_id}
