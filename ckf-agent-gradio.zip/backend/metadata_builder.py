from docx import Document
import re, os, json

def parse_docx_for_metadata(docx_path):
    path = docx_path.replace('file://', '')
    if not os.path.exists(path):
        return {}, []
    doc = Document(path)
    paragraphs = [p.text.strip() for p in doc.paragraphs if p.text.strip()]
    data_dict = {}
    rules = []
    collecting_dict = False
    for idx, line in enumerate(paragraphs):
        low = line.lower()
        if 'data dictionary' in low:
            collecting_dict = True
            continue
        if collecting_dict:
            if re.match(r'^[A-Z][A-Za-z0-9 \-]{0,40}:?$', line) and len(line.split())<6 and len(line)>2 and idx>0 and 'data dictionary' not in paragraphs[idx-1].lower():
                collecting_dict = False
            else:
                m = re.match(r'^(?P<key>[A-Za-z0-9_ \-]+)\s*[:\-]\s*(?P<desc>.+)$', line)
                if m:
                    key = m.group('key').strip().replace(' ', '')
                    desc = m.group('desc').strip()
                    data_dict[key] = {'table': 'Production', 'description': desc}
                else:
                    m = re.match(r'^(?P<key>[A-Za-z0-9_ \-]+)\s*\(.*\)\s*[:\-]?\s*(?P<desc>.*)$', line)
                    if m and m.group('desc').strip():
                        key = m.group('key').strip().replace(' ', '')
                        data_dict[key] = {'table': 'Production', 'description': m.group('desc').strip()}
        if any(k in low for k in ['tolerance', 'formula', 'kpi', 'rule', 'validation', 'recover', 'recovery', 'temporal', 'order']):
            snippet = ''
            if idx-1 >=0:
                snippet += paragraphs[idx-1] + ' '
            snippet += line + ' '
            if idx+1 < len(paragraphs):
                snippet += paragraphs[idx+1]
            rules.append({'id': f'rule_{len(rules)+1}', 'text': snippet[:1000], 'source': path})
    for table in doc.tables:
        for row in table.rows:
            cells = [c.text.strip() for c in row.cells]
            if len(cells) >= 2:
                key = cells[0].replace(' ', '')
                desc = cells[1]
                if key and desc:
                    data_dict.setdefault(key, {'table': 'Production', 'description': desc})
    return data_dict, rules

if __name__ == '__main__':
    import sys
    path = sys.argv[1] if len(sys.argv)>1 else 'file:///mnt/data/Manufacturing_Process_and_KPIs_Documentation.docx'
    dd, rules = parse_docx_for_metadata(path)
    print('Fields extracted:', len(dd))
    print('Rules extracted:', len(rules))
    print(list(dd.keys())[:20])
