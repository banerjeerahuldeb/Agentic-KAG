import os, json
from openai import OpenAI

OPENAI_KEY = os.environ.get('OPENAI_API_KEY')
OPENAI_MODEL = os.environ.get('OPENAI_MODEL','gpt-4o-mini')
client = OpenAI(api_key=OPENAI_KEY)

SYSTEM_PROMPT = """You are an accurate enterprise manufacturing assistant.
- Use only the numeric values and KPI outputs provided.
- Explain the result, list validations, and cite provenance snippets.
- Do NOT invent values or recompute KPIs beyond simple display.
"""

def call_llm(payload: dict):
    question = payload.get('question')
    sql = payload.get('sql')
    row = payload.get('row')
    kpis = payload.get('kpis')
    rules = payload.get('rules', [])

    rules_text = "\n".join([r.get('text','')[:400] for r in rules])

    user_prompt = f"""User question:
{question}

SQL executed:
{sql}

Row data:
{json.dumps(row, default=str, indent=2)}

KPI engine output:
{json.dumps(kpis, default=str, indent=2)}

Relevant rules:
{rules_text}

Provide a concise, human-friendly answer using only the provided numbers and rules. Include provenance and next steps if flags exist.
"""

    resp = client.chat.completions.create(
        model=OPENAI_MODEL,
        messages=[
            {"role":"system","content":SYSTEM_PROMPT},
            {"role":"user","content":user_prompt}
        ],
        max_tokens=400,
        temperature=0.0
    )
    return resp.choices[0].message.content
