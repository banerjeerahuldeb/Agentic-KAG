from sqlalchemy import create_engine, text
from sqlalchemy.orm import sessionmaker
from .config import settings
import os

DATABASE_URL = os.environ.get('DATABASE_URL', None)

if DATABASE_URL:
    engine = create_engine(DATABASE_URL, pool_pre_ping=True)
    SessionLocal = sessionmaker(bind=engine)
else:
    engine = None
    SessionLocal = None

def run_sql(sql: str, params: dict = None):
    params = params or {}
    if engine is None:
        return None
    with engine.connect() as conn:
        result = conn.execute(text(sql), params)
        row = result.fetchone()
        if row is None:
            return None
        return dict(row._mapping)
