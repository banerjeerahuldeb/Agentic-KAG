import os
import chromadb
from chromadb.config import Settings as ChromaSettings

def rag_search(question: str, k: int = 6):
    chroma_dir = os.environ.get('CHROMA_DIR', './chroma_db')
    client = chromadb.Client(ChromaSettings(chroma_db_impl='duckdb+parquet', persist_directory=chroma_dir))
    try:
        coll = client.get_collection('manufacturing_docs')
    except Exception:
        return []
    res = coll.query(query_texts=[question], n_results=k)
    docs = []
    if res and 'ids' in res and len(res['ids'])>0:
        for i in range(len(res['ids'][0])):
            docs.append({'id': res['ids'][0][i], 'text': res['documents'][0][i], 'meta': res['metadatas'][0][i]})
    return docs
