import os, json
from docx import Document
import chromadb
from chromadb.config import Settings as ChromaSettings
from openai import OpenAI

MODEL_EMBED = os.environ.get('OPENAI_EMBEDDING_MODEL', 'text-embedding-3-small')
OPENAI_KEY = os.environ.get('OPENAI_API_KEY')

client = OpenAI(api_key=OPENAI_KEY)

def load_doc_text(doc_path):
    p = doc_path.replace('file://','')
    if not os.path.exists(p):
        raise FileNotFoundError(p)
    doc = Document(p)
    texts = []
    for par in doc.paragraphs:
        t = par.text.strip()
        if t:
            texts.append(t)
    for t in doc.tables:
        for r in t.rows:
            row_text = ' | '.join([c.text.strip() for c in r.cells if c.text.strip()])
            if row_text:
                texts.append(row_text)
    return '\n\n'.join(texts)

def chunk_text(text, max_words=120):
    sentences = [s.strip() for s in text.replace('\n',' ').split('. ') if s.strip()]
    chunks = []
    cur = []
    cur_words = 0
    for s in sentences:
        w = len(s.split())
        if cur_words + w > max_words and cur:
            chunks.append('. '.join(cur).strip())
            cur = [s]
            cur_words = w
        else:
            cur.append(s)
            cur_words += w
    if cur:
        chunks.append('. '.join(cur).strip())
    return chunks

def embed_texts(texts):
    resp = client.embeddings.create(model=MODEL_EMBED, input=texts)
    return [d.embedding for d in resp.data]

def ingest_to_chroma(doc_path, chroma_dir=None):
    chroma_dir = chroma_dir or os.environ.get('CHROMA_DIR','./chroma_db')
    client_chroma = chromadb.Client(ChromaSettings(chroma_db_impl='duckdb+parquet', persist_directory=chroma_dir))
    coll = client_chroma.get_or_create_collection('manufacturing_docs')
    raw = load_doc_text(doc_path)
    chunks = chunk_text(raw, max_words=120)
    if not chunks:
        return 0
    ids = [f'chunk_{i}' for i in range(len(chunks))]
    metadatas = [{'source': doc_path, 'chunk_index': i} for i in range(len(chunks))]
    embs = embed_texts(chunks)
    coll.add(ids=ids, documents=chunks, metadatas=metadatas, embeddings=embs)
    client_chroma.persist()
    return len(chunks)

if __name__ == '__main__':
    import sys
    path = sys.argv[1] if len(sys.argv)>1 else os.environ.get('MANUFACTURING_DOC_URL')
    n = ingest_to_chroma(path)
    print(f'Ingested {n} chunks')
