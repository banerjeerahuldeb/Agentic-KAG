from pydantic import BaseSettings

class Settings(BaseSettings):
    MANUFACTURING_DOC_URL: str = "file:///mnt/data/Manufacturing_Process_and_KPIs_Documentation.docx"
    TABLE_SCRIPT_PATH: str = "/mnt/data/TableScript.txt"
    CHROMA_DIR: str = "./chroma_db"
    MAX_RAG_CHUNKS: int = 6
    AUDIT_DB_TABLE: str = "AgentAudit"
    class Config:
        env_file = ".env"

settings = Settings()
