import os, json
from .metadata_builder import parse_docx_for_metadata
CACHE_PATH = './backend/metadata_cache.json'

def load_metadata():
    if os.path.exists(CACHE_PATH):
        with open(CACHE_PATH, 'r', encoding='utf-8') as f:
            j = json.load(f)
            return j.get('data_dictionary', {}), j.get('rules', [])
    dd, rules = parse_docx_for_metadata(os.environ.get('MANUFACTURING_DOC_URL','file:///mnt/data/Manufacturing_Process_and_KPIs_Documentation.docx'))
    with open(CACHE_PATH, 'w', encoding='utf-8') as f:
        json.dump({'data_dictionary': dd, 'rules': rules}, f, indent=2)
    return dd, rules

DATA_DICTIONARY, RULE_SNIPPETS = load_metadata()
