from typing import Dict, Any

def safe_div(a, b):
    try:
        if b in (None, 0):
            return None
        return float(a) / float(b)
    except Exception:
        return None

def compute_kpis(row: Dict[str, Any], requested_fields=None):
    requested_fields = requested_fields or []
    out = {'validations': [], 'flags': [], 'kpis': {}}
    for col in ['CastWeight','ScalpLoss','HotlineStartWeight','HotlineExitWeight','PackedWeight']:
        v = row.get(col)
        if v is not None:
            try:
                if float(v) < 0:
                    out['validations'].append(f"{col} negative")
            except Exception:
                pass
    cd = row.get('CastDate')
    hs = row.get('HotlineStartDate')
    he = row.get('HotlineExitDate')
    pd = row.get('PackedDate')
    try:
        if cd and hs and he and pd:
            if not (cd <= hs <= he <= pd):
                out['validations'].append('Temporal order violation')
    except Exception:
        pass
    packed = row.get('PackedWeight')
    hotline_exit = row.get('HotlineExitWeight')
    try:
        if packed is not None and hotline_exit is not None:
            if float(packed) > float(hotline_exit) * 1.01:
                out['validations'].append('PackedWeight exceeds HotlineExitWeight + 1% tolerance')
    except Exception:
        pass
    hl_recovery = safe_div(row.get('HotlineStartWeight') or 0, row.get('HotlineExitWeight'))
    if hl_recovery is not None:
        out['kpis']['HL_Recovery'] = round(hl_recovery, 4)
        if hl_recovery > 1.05 or hl_recovery < 0.7:
            out['flags'].append('HL_Recovery_out_of_range')
    if row.get('CastWeight') is not None and row.get('PackedWeight') is not None:
        tr = safe_div(row.get('CastWeight'), row.get('PackedWeight'))
        if tr is not None:
            out['kpis']['Total_Recovery'] = round(tr, 4)
    return out
