import uuid, datetime, json, os
from .config import settings
try:
    from .db import engine
except Exception:
    engine = None

def record_audit(user_id: str, question: str, sql: str, kpi_result: dict, rag_docs: list, llm_resp: str):
    audit_id = str(uuid.uuid4())
    created_at = datetime.datetime.utcnow()
    if engine is None:
        p = './backend/audit_logs.jsonl'
        entry = {'audit_id': audit_id, 'user_id': user_id, 'question': question, 'sql': sql, 'kpi': kpi_result, 'rag': rag_docs, 'llm': llm_resp, 'ts': created_at.isoformat()}
        with open(p, 'a', encoding='utf-8') as f:
            f.write(json.dumps(entry) + '\n')
        return audit_id
    sql_text = f"INSERT INTO {settings.AUDIT_DB_TABLE} (AuditId, UserId, QueryText, SQLExecuted, KPIEngineResult, RAGDocSnippets, LLMResponse, CreatedAt) VALUES (:aid, :uid, :q, :sql, :kpi, :rag, :llm, :dt)"
    with engine.connect() as conn:
        conn.execute(sql_text, {
            'aid': audit_id,
            'uid': user_id,
            'q': question,
            'sql': sql,
            'kpi': json.dumps(kpi_result, default=str),
            'rag': json.dumps(rag_docs, default=str),
            'llm': llm_resp,
            'dt': created_at
        })
    return audit_id
