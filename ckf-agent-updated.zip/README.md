# CKF-Agent Updated
Includes Chroma ingestion, sentence-transformers embeddings, ctransformers local LLM adapter, and docx metadata parser.
