from sqlalchemy import create_engine, text
from sqlalchemy.orm import sessionmaker
from .config import settings

engine = create_engine(settings.DATABASE_URL, pool_pre_ping=True)
SessionLocal = sessionmaker(bind=engine)

def run_sql(sql: str, params: dict = None):
    params = params or {}
    with engine.connect() as conn:
        result = conn.execute(text(sql), params)
        row = result.fetchone()
        if row is None:
            return None
        return dict(row._mapping)
