# metadata_builder.py
# Parses the Manufacturing_Process_and_KPIs_Documentation.docx to extract:
# - a simple DATA_DICTIONARY (key -> {table, description})
# - RULE_SNIPPETS list with small text pieces useful for provenance
#
# This is heuristic-based and should be tuned per document structure.
from docx import Document
import re, os, json

def parse_docx_for_metadata(docx_path):
    path = docx_path.replace("file://", "")
    if not os.path.exists(path):
        return {}, []
    doc = Document(path)
    paragraphs = [p.text.strip() for p in doc.paragraphs if p.text.strip()]
    data_dict = {}
    rules = []
    # Heuristics:
    # - Sections that start with 'Data Dictionary' or 'Data Dictionary:' collect following lines containing ' - ' or ':' or are in a table
    # - Lines containing keywords 'tolerance', 'formula', 'KPI', 'rule', 'validation', 'recover' are added to rules
    collecting_dict = False
    for idx, line in enumerate(paragraphs):
        low = line.lower()
        if 'data dictionary' in low:
            collecting_dict = True
            continue
        if collecting_dict:
            # stop collecting if next section header-like appears
            if re.match(r'^[A-Z][A-Za-z0-9 \-]{0,40}:?$', line) and len(line.split())<6 and len(line)>2 and idx>0 and 'data dictionary' not in paragraphs[idx-1].lower():
                # likely new header -> stop
                collecting_dict = False
            else:
                # look for patterns like "PackedWeight - Description" or "PackedWeight: Description"
                m = re.match(r'^(?P<key>[A-Za-z0-9_ \-]+)\s*[:\-]\s*(?P<desc>.+)$', line)
                if m:
                    key = m.group('key').strip().replace(' ', '')
                    desc = m.group('desc').strip()
                    data_dict[key] = {'table': 'Production', 'description': desc}
                else:
                    # maybe "PackedWeight (kg) : ...", try to parse
                    m = re.match(r'^(?P<key>[A-Za-z0-9_ \-]+)\s*\(.*\)\s*[:\-]?\s*(?P<desc>.*)$', line)
                    if m and m.group('desc').strip():
                        key = m.group('key').strip().replace(' ', '')
                        data_dict[key] = {'table': 'Production', 'description': m.group('desc').strip()}
        # rule detection
        if any(k in low for k in ['tolerance', 'formula', 'kpi', 'rule', 'validation', 'recover', 'recovery', 'temporal', 'order']):
            # store surrounding context (previous + this + next)
            snippet = ''
            if idx-1 >=0:
                snippet += paragraphs[idx-1] + ' '
            snippet += line + ' '
            if idx+1 < len(paragraphs):
                snippet += paragraphs[idx+1]
            rules.append({'id': f'rule_{len(rules)+1}', 'text': snippet[:1000], 'source': path})
    # also parse tables in docx for data dictionary if present
    for table in doc.tables:
        # assume first col = field, second col = description
        for row in table.rows:
            cells = [c.text.strip() for c in row.cells]
            if len(cells) >= 2:
                key = cells[0].replace(' ', '')
                desc = cells[1]
                if key and desc:
                    data_dict.setdefault(key, {'table': 'Production', 'description': desc})
    return data_dict, rules

if __name__ == '__main__':
    import os, sys
    path = sys.argv[1] if len(sys.argv)>1 else 'file:///mnt/data/Manufacturing_Process_and_KPIs_Documentation.docx'
    dd, rules = parse_docx_for_metadata(path)
    out = {'data_dictionary': dd, 'rules': rules}
    print(json.dumps(out, indent=2))
