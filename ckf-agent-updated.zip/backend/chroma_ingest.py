# chroma_ingest.py
# Ingest the Manufacturing doc into Chroma with embeddings from sentence-transformers.
import os, math, json
from docx import Document
from sentence_transformers import SentenceTransformer
import chromadb
from chromadb.config import Settings as ChromaSettings
from chromadb.utils import embedding_functions
from .config import settings

MODEL_NAME = 'all-MiniLM-L6-v2'

def chunk_text(text, max_tokens=200):
    # naive chunker by sentences, target ~200 words (not tokens)
    sentences = [s.strip() for s in text.replace('\n', ' ').split('.') if s.strip()]
    chunks = []
    cur = ''
    for s in sentences:
        if len((cur + ' ' + s).split()) > max_tokens:
            chunks.append(cur.strip())
            cur = s
        else:
            cur = (cur + ' ' + s).strip()
    if cur:
        chunks.append(cur.strip())
    return chunks

def load_doc(path):
    path = path.replace('file://', '')
    if not os.path.exists(path):
        raise FileNotFoundError(path)
    doc = Document(path)
    texts = []
    # include paragraphs
    for p in doc.paragraphs:
        if p.text and p.text.strip():
            texts.append(p.text.strip())
    # include tables (concatenate rows)
    for t in doc.tables:
        for r in t.rows:
            row_text = ' | '.join([c.text.strip() for c in r.cells if c.text.strip()])
            if row_text:
                texts.append(row_text)
    return '\n\n'.join(texts)

def embed_texts(texts, model):
    return model.encode(texts, show_progress_bar=True, convert_to_numpy=True)

def ingest_to_chroma(doc_path, chroma_dir=None):
    chroma_dir = chroma_dir or settings.CHROMA_DIR
    client = chromadb.Client(ChromaSettings(chroma_db_impl='duckdb+parquet', persist_directory=chroma_dir))
    coll = client.get_or_create_collection('manufacturing_docs')
    model = SentenceTransformer(MODEL_NAME)
    raw = load_doc(doc_path)
    chunks = chunk_text(raw, max_tokens=120)
    ids = []
    metadatas = []
    docs = []
    for i, c in enumerate(chunks):
        ids.append(f'doc_chunk_{i}')
        docs.append(c)
        metadatas.append({'source': doc_path, 'chunk_index': i})
    # compute embeddings
    embs = embed_texts(docs, model).tolist()
    # Use chroma's add with embeddings via embedding_function? We'll use add with embeddings argument
    try:
        coll.add(ids=ids, documents=docs, metadatas=metadatas, embeddings=embs)
    except Exception as e:
        # fallback: use embedding function wrapper
        ef = embedding_functions.ExternalEmbeddingFunction(func=lambda texts: [list(v) for v in embed_texts(texts, model)])
        client._reset()
        coll = client.get_or_create_collection('manufacturing_docs', embedding_function=ef)
        coll.add(ids=ids, documents=docs, metadatas=metadatas)
    client.persist()
    return len(chunks)

if __name__ == '__main__':
    import sys
    path = sys.argv[1] if len(sys.argv)>1 else 'file:///mnt/data/Manufacturing_Process_and_KPIs_Documentation.docx'
    n = ingest_to_chroma(path)
    print(f'Ingested {n} chunks')
