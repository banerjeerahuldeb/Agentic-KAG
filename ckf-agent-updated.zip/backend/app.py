from fastapi import FastAPI
from pydantic import BaseModel
from .agent import answer_question

app = FastAPI(title='CKF Universal Agent - Updated')

class Query(BaseModel):
    question: str
    user_id: str = 'user'

@app.post('/api/v1/query')
def query(q: Query):
    return answer_question(q.question, q.user_id)
