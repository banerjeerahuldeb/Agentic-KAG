from pydantic import BaseSettings

class Settings(BaseSettings):
    DATABASE_URL: str
    VECTOR_STORE: str = "chroma"
    CHROMA_DIR: str = "./chroma_db"
    MANUFACTURING_DOC_URL: str = "file:///mnt/data/Manufacturing_Process_and_KPIs_Documentation.docx"
    TABLE_SCRIPT_PATH: str = "/mnt/data/TableScript.txt"
    MAX_RAG_CHUNKS: int = 6
    CTRANSFORMERS_MODEL_PATH: str = ""  # set to local model path if using ctransformers
    class Config:
        env_file = ".env"

settings = Settings()
