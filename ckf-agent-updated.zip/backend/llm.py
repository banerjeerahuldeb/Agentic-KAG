# llm.py - local LLM adapter using ctransformers (if available).
# Install: pip install ctransformers
import os
from .config import settings

CTRANS_PATH = settings.CTRANSFORMERS_MODEL_PATH or os.environ.get('CTRANSFORMERS_MODEL_PATH','')

def call_llm(payload: dict):
    question = payload.get('question')
    sql = payload.get('sql')
    row = payload.get('row')
    kpis = payload.get('kpis')
    rules = payload.get('rules', [])

    rules_text = '\n'.join([r.get('text','')[:400] for r in rules])

    prompt = f"""User question:
{question}

SQL executed:
{sql}

Row data:
{row}

KPI engine output:
{kpis}

Relevant rules:
{rules_text}

Provide a concise, human-friendly answer using the provided numbers and rules. Include provenance and next steps if flags exist.
"""

    # If ctransformers model path provided, use local model
    if CTRANS_PATH:
        try:
            from ctransformers import AutoModelForCausalLM
            model = AutoModelForCausalLM(CTRANS_PATH, model_type='auto')
            # generate with reasonable defaults
            out = model.generate(prompt, max_new_tokens=512, top_k=50)
            # model.generate may return bytes or str
            if isinstance(out, bytes):
                return out.decode('utf-8', errors='ignore')
            return str(out)
        except Exception as e:
            # fallback to returning prompt as debug if model fails
            return f"[Local LLM failed: {e}]\n\n{prompt[:4000]}"
    else:
        return "[No local LLM configured. Set CTRANSFORMERS_MODEL_PATH in .env to use local LLM.]\n" + prompt[:4000]
