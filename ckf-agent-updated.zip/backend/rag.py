# rag.py - query Chroma for relevant doc snippets
from .config import settings
import chromadb
from chromadb.config import Settings as ChromaSettings

def rag_search(question: str, k: int = None):
    k = k or settings.MAX_RAG_CHUNKS
    client = chromadb.Client(ChromaSettings(chroma_db_impl='duckdb+parquet', persist_directory=settings.CHROMA_DIR))
    try:
        coll = client.get_collection('manufacturing_docs')
    except Exception:
        return []
    res = coll.query(query_texts=[question], n_results=k)
    docs = []
    if res and 'ids' in res and len(res['ids'])>0:
        for i in range(len(res['ids'][0])):
            docs.append({'id': res['ids'][0][i], 'text': res['documents'][0][i], 'meta': res['metadatas'][0][i]})
    return docs
