import streamlit as st
import requests

API = st.secrets.get('API_BASE', 'http://localhost:8000/api/v1/query')

st.title('CKF - Enterprise Chat Agent (Updated)')

st.sidebar.markdown('## Admin')
if st.sidebar.button('Ingest doc to Chroma'):
    # call a local endpoint or run script - for demo we show instructions
    st.sidebar.info('Run: python backend/chroma_ingest.py file:///mnt/data/Manufacturing_Process_and_KPIs_Documentation.docx')

if 'chat' not in st.session_state:
    st.session_state.chat = []

def ask():
    q = st.session_state.inp.strip()
    if not q:
        return
    st.session_state.chat.append(('user', q))
    resp = requests.post(API, json={'question': q, 'user_id': 'demo_user'})
    try:
        data = resp.json()
    except Exception:
        st.session_state.chat.append(('agent', f'Error: {resp.text}'))
        st.session_state.inp = ''
        return
    if 'answer' in data:
        st.session_state.chat.append(('agent', data['answer']))
        st.session_state.chat.append(('system', f"Row: {data.get('row')}\nKPIs: {data.get('kpis')}\nAuditId: {data.get('audit_id')}" ))
    else:
        st.session_state.chat.append(('agent', data.get('error', 'No answer')))

    st.session_state.inp = ''

for role, msg in st.session_state.chat:
    if role == 'user':
        st.markdown(f"**You:** {msg}")
    elif role == 'agent':
        st.markdown(f"**Agent:** {msg}")
    else:
        st.markdown(f"*{msg}*")

st.text_input('Ask anything about manufacturing data...', key='inp', on_change=ask)
