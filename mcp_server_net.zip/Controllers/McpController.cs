using Microsoft.AspNetCore.Mvc;
using McpServer.Data;
using McpServer.Models;

namespace McpServer.Controllers
{
    [ApiController]
    [Route("mcp/v1/[controller]")]
    public class EntitiesController : ControllerBase
    {
        private readonly string _cs;
        public EntitiesController(IConfiguration cfg)
        {
            _cs = cfg.GetConnectionString("SqlServer")!;
        }

        [HttpGet("Asset")]
        public async Task<IActionResult> GetAssets([FromQuery] string? status, int limit=100)
        {
            using var sql = new SqlConnector(_cs);
            var rows = await sql.QueryAsync(
                @"SELECT TOP (@Limit) AssetId, Name, Latitude, Longitude, Status, UpdatedAt 
                  FROM dbo.Assets 
                  WHERE (@Status IS NULL OR Status=@Status)
                  ORDER BY UpdatedAt DESC",
                new {Limit=limit, Status=status});

            var entities = rows.Select(r => new McpEntity{
                Id=$"asset:{r.AssetId}",
                Type="Asset",
                Attributes=new {
                    name=r.Name,
                    location=new {lat=(double)r.Latitude, lon=(double)r.Longitude},
                    status=r.Status
                },
                LastSeen=r.UpdatedAt
            });

            return Ok(new {entities});
        }
    }
}
