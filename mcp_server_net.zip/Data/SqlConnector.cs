using System.Data;
using Microsoft.Data.SqlClient;
using Dapper;

namespace McpServer.Data
{
    public class SqlConnector : IDisposable
    {
        private readonly SqlConnection _conn;
        public SqlConnector(string cs)
        {
            _conn = new SqlConnection(cs);
            _conn.Open();
        }

        public Task<IEnumerable<dynamic>> QueryAsync(string sql, object? param=null)
            => _conn.QueryAsync(sql, param);
        public void Dispose() => _conn.Dispose();
    }
}
