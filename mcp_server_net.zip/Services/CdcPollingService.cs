using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using Microsoft.AspNetCore.SignalR;
using McpServer.Hubs;
using McpServer.Models;

namespace McpServer.Services
{
    public class CdcPollingService : BackgroundService
    {
        private readonly ILogger<CdcPollingService> _log;
        public CdcPollingService(ILogger<CdcPollingService> log){_log = log;}

        protected override async Task ExecuteAsync(CancellationToken ct)
        {
            while(!ct.IsCancellationRequested)
            {
                _log.LogInformation("Polling CDC (placeholder implementation)");
                await Task.Delay(2000, ct);
            }
        }
    }
}
