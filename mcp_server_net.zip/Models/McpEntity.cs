namespace McpServer.Models
{
    public class McpEntity
    {
        public string Id { get; set; }
        public string Type { get; set; }
        public object Attributes { get; set; }
        public DateTimeOffset LastSeen { get; set; }
    }
}
