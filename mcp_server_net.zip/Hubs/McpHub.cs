using Microsoft.AspNetCore.SignalR;
using McpServer.Models;

namespace McpServer.Hubs
{
    public class McpHub : Hub { }
}
